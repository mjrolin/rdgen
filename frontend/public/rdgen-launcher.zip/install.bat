@echo off
echo ========================================
echo RDGen Launcher Installer
echo ========================================
echo.

:: Check for admin rights
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo ERROR: This script requires administrator privileges.
    echo Please right-click and select "Run as administrator"
    pause
    exit /b 1
)

:: Create installation directory
echo Creating installation directory...
mkdir "C:\Program Files\RDGen" 2>nul

:: Copy launcher
echo Copying launcher...
copy /Y "rdgen-launcher.exe" "C:\Program Files\RDGen\rdgen-launcher.exe"
if %errorLevel% neq 0 (
    echo ERROR: Failed to copy launcher executable
    pause
    exit /b 1
)

:: Register protocol handler
echo Registering rdgen:// protocol handler...
reg add "HKEY_CLASSES_ROOT\rdgen" /ve /d "URL:RDGen Protocol" /f
reg add "HKEY_CLASSES_ROOT\rdgen" /v "URL Protocol" /d "" /f
reg add "HKEY_CLASSES_ROOT\rdgen\shell\open\command" /ve /d "\"C:\Program Files\RDGen\rdgen-launcher.exe\" \"%%1\"" /f

if %errorLevel% neq 0 (
    echo ERROR: Failed to register protocol handler
    pause
    exit /b 1
)

echo.
echo ========================================
echo Installation complete!
echo ========================================
echo.
echo The rdgen:// protocol handler is now registered.
echo.
echo Test it by opening this URL in your browser:
echo   rdgen://connect/test
echo.
pause
